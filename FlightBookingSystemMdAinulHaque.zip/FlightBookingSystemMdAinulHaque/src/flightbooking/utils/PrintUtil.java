package flightbooking.utils;

public class PrintUtil {

    // Prints a formatted message
    public static void printMessage(String message) {
        System.out.println("[INFO] " + message);
    }

    // Prints an error message
    public static void printError(String errorMessage) {
        System.err.println("[ERROR] " + errorMessage);
    }
}
