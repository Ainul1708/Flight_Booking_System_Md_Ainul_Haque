package flightbooking.utils;

import flightbooking.models.Passenger;

public class DiscountUtil 
{
    public static double calculateDiscount(Passenger passenger) 
    {
        switch (passenger.getCategory()) 
        {
            case "Senior Citizen": 
            	return 0.20;
            case "Army": 
            	return 0.30;
            case "VIP": 
            	return 0.25;
            case "Celebrity": 
            	return 0.15;
            case "Flying Personnel": 
            	return 0.10;
            default: 
            	return 0.0;
        }
    }
}

