package flightbooking.utils;

import flightbooking.models.Flight;
import flightbooking.models.Passenger;
import flightbooking.models.Ticket;
import flightbooking.services.BookingService;
import flightbooking.services.FlightService;
import flightbooking.services.PassengerService;

import java.util.InputMismatchException;
import java.util.Scanner;

public class FlightBookingSystem {
    public static void main(String[] args) {
        FlightService flightService = new FlightService();
        PassengerService passengerService = new PassengerService();
        BookingService bookingService = new BookingService();
        Scanner scanner = new Scanner(System.in);

        try {
            // Sample Flights
            flightService.addFlight(new Flight("AI101", "Kolkata", "Delhi", 5000, 5));
            flightService.addFlight(new Flight("AI102", "Kolkata", "Bangalore", 6800, 4));
            flightService.addFlight(new Flight("AI103", "Kolkata", "Mumbai", 15000, 5));
            flightService.addFlight(new Flight("AI104", "Kolkata", "Pune", 6700, 4));
            flightService.addFlight(new Flight("AI105", "Kolkata", "Hyderabad", 5400, 5));
            flightService.addFlight(new Flight("AI106", "Kolkata", "Chennai", 6230, 4));
            flightService.addFlight(new Flight("AI107", "Kolkata", "Kochi", 16200, 5));
            flightService.addFlight(new Flight("AI108", "Kolkata", "Chandigarh", 6770, 4));

            while (true) {
                System.out.println("\n1. Add Passenger  2. Delete Passenger  3. View Flights  4. View Passengers");
                System.out.println("5. Book Ticket  6. Cancel Booking  7. View Bookings  8. View Category  9. Exit");
                System.out.print("Enter your choice: ");

                try {
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    if (choice == 9) {
                        System.out.println("Exiting the system. Goodbye!");
                        break;
                    }

                    switch (choice) {
                        case 1: // Add Passenger
                            try {
                                System.out.print("Enter Name: ");
                                String name = scanner.nextLine();
                                System.out.print("Enter Age: ");
                                int age = scanner.nextInt();
                                scanner.nextLine(); // Consume newline
                                System.out.print("Enter Category: Senior Citizen or Army or VIP or Celebrity or Flying Personnel or Regular ");
                                String category = scanner.nextLine();
                                passengerService.addPassenger(new Passenger(name, age, category));
                            } catch (InputMismatchException e) {
                                System.out.println("Invalid input for age. Please enter a valid number.");
                                scanner.nextLine(); // Clear invalid input
                            }
                            break;

                        case 2: // Delete Passenger
                            System.out.print("Enter Passenger Name to Remove: ");
                            String passengerName = scanner.nextLine();
                            passengerService.removePassenger(passengerName);
                            break;

                        case 3: // View Flights
                            flightService.listFlights();
                            break;

                        case 4: // View Passengers
                            passengerService.listPassengers();
                            break;

                        case 5: // Book Ticket
                            System.out.print("Enter Passenger Name: ");
                            String passengerToBook = scanner.nextLine();
                            Passenger passenger = passengerService.findPassengerByName(passengerToBook);

                            if (passenger == null) {
                                System.out.println("Passenger not found.");
                                break;
                            }

                            System.out.print("Enter Flight Number: ");
                            String flightNumber = scanner.nextLine();

                            Flight flight = null;
                            for (Flight f : flightService.getFlights()) {
                                if (f.getFlightNumber().equals(flightNumber)) {
                                    flight = f;
                                    break;
                                }
                            }

                            if (flight == null) {
                                System.out.println("Flight not found.");
                                break;
                            }

                            Ticket ticket = bookingService.bookFlight(flight, passenger);
                            if (ticket != null) {
                                System.out.println("Ticket booked successfully!");
                                ticket.displayTicket();
                            }
                            break;

                        case 6: // Cancel Booking
                            System.out.print("Enter Passenger Name to Cancel Booking: ");
                            String passengerToCancel = scanner.nextLine();
                            Passenger cancelPassenger = passengerService.findPassengerByName(passengerToCancel);

                            if (cancelPassenger == null) {
                                System.out.println("Passenger not found.");
                                break;
                            }

                            Ticket ticketToCancel = bookingService.findBookingByPassenger(cancelPassenger);
                            if (ticketToCancel != null) {
                                bookingService.cancelBooking(ticketToCancel);
                            } else {
                                System.out.println("No booking found for passenger.");
                            }
                            break;

                        case 7: // View Bookings
                            bookingService.listBookings();
                            break;

                        case 8: // View Category
                            passengerService.listCategories();
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.nextLine(); // Clear invalid input
                }
            }
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            scanner.close(); // Ensure the scanner is closed
        }
    }
}