package flightbooking.utils;

public class ValidationUtil {
    
    // Validates if the given string is not null or empty
    public static boolean isValidString(String str) {
        return str != null && !str.trim().isEmpty();
    }

    // Validates if the given number is positive
    public static boolean isPositiveNumber(int number) {
        return number > 0;
    }
}
