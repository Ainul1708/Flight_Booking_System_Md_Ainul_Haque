package flightbooking.models;

public class Flight {
    private String flightNumber;
    private String origin;
    private String destination;
    private double basePrice;
    private int availableSeats;

    public Flight(String flightNumber, String origin, String destination, double basePrice, int availableSeats) {
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.basePrice = basePrice;
        this.availableSeats = availableSeats;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getOrigin() {
        return origin;
    }

    public String getDestination() {
        return destination;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public boolean bookSeat() {
        if (availableSeats > 0) {
            availableSeats--;
            return true;
        }
        return false;
    }

    public void releaseSeat() {
        availableSeats++;
    }

    public void displayFlightDetails() {
        System.out.println("Flight Number: " + flightNumber);
        System.out.println("Origin: " + origin);
        System.out.println("Destination: " + destination);
        System.out.println("Base Price: " + basePrice);
        System.out.println("Available Seats: " + availableSeats+"\n");
    }

   /* @Override
    public String toString() {
        return "FlightNumber: " + flightNumber + ", Origin: " + origin + ", Destination: " + destination + ", Price: " + basePrice + ", Available Seats: " + availableSeats;
    } */
}