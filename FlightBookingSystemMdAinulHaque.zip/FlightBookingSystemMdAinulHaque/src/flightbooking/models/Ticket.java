package flightbooking.models;

public class Ticket {
    private Flight flight;
    private Passenger passenger;
    private double finalPrice;

    public Ticket(Flight flight, Passenger passenger, double finalPrice) {
        this.flight = flight;
        this.passenger = passenger;
        this.finalPrice = finalPrice;
    }

    public Flight getFlight() {
        return flight;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public double getFinalPrice() {
        return finalPrice;
    }

    public void displayTicket() {
        System.out.println("\nTicket Details:");
        System.out.println("Passenger Name: " + passenger.getName());
        System.out.println("Flight Number: " + flight.getFlightNumber());
        System.out.println("Final Price: " + finalPrice);
    }
}