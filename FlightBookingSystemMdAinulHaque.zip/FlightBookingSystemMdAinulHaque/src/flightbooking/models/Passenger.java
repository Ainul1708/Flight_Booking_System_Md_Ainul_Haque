package flightbooking.models;

public class Passenger {
    private String name;
    private int age;
    private String category; // "Senior Citizen", "Army", "VIP", "Celebrity", "Flying Personnel", "Regular"

    public Passenger(String name, int age, String category) {
        this.name = name;
        this.age = age;
        this.category = category;
    }

    public String getCategory() 
    { 
    	return category; 
    }
    public int getAge() 
    {
    	return age; 
    }
    public String getName() 
    { 
    	return name; 
    }
    
    public void displayPassenger() {
        System.out.println("Passenger: " + name + " | Age: " + age + " | Category: " + category);
    }
}

