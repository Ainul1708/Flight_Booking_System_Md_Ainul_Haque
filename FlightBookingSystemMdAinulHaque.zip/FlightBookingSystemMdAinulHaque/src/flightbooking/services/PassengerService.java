package flightbooking.services;

import flightbooking.models.Passenger;

import java.util.ArrayList;
import java.util.List;

public class PassengerService {
    private List<Passenger> passengers = new ArrayList<>();

    public void addPassenger(Passenger passenger) {
        passengers.add(passenger);
    }

    public void removePassenger(String name) {
        passengers.removeIf(p -> p.getName().equalsIgnoreCase(name));
    }

    public Passenger findPassengerByName(String name) {
        for (Passenger passenger : passengers) {
            if (passenger.getName().equalsIgnoreCase(name)) {
                return passenger;
            }
        }
        return null;
    }

    public void listPassengers() {
        if (passengers.isEmpty()) {
            System.out.println("No passengers found.");
            return;
        }
        for (Passenger passenger : passengers) {
            System.out.println("Name: " + passenger.getName() +
                               ", Age: " + passenger.getAge() +
                               ", Category: " + passenger.getCategory());
        }
    }

    // New method to list passenger categories
    public void listCategories() {
        if (passengers.isEmpty()) {
            System.out.println("No passengers found.");
            return;
        }
        System.out.println("Passenger Categories:");
        for (Passenger passenger : passengers) {
            System.out.println(passenger.getCategory());
        }
    }
}