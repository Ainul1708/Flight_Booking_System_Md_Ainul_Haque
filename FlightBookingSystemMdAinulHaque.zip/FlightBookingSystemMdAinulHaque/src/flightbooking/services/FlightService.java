package flightbooking.services;

import flightbooking.models.Flight;
import java.util.ArrayList;

public class FlightService 
{
    private ArrayList<Flight> flights = new ArrayList<>();

    public void addFlight(Flight flight) 
    {
        flights.add(flight);
    }

    public ArrayList<Flight> getFlights() 
    { 
    	return flights; 
    }
    
    public void listFlights() 
    {
        for (Flight flight : flights) 
        {
            flight.displayFlightDetails();
        }
    }
}

