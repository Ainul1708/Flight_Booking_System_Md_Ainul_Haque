package flightbooking.services;

import flightbooking.models.Flight;
import flightbooking.models.Passenger;
import flightbooking.models.Ticket;
import flightbooking.utils.DiscountUtil;

import java.util.ArrayList;

public class BookingService {
    private ArrayList<Ticket> bookings = new ArrayList<>();

    public Ticket bookFlight(Flight flight, Passenger passenger) {
        if (flight.bookSeat()) {
            double discount = DiscountUtil.calculateDiscount(passenger);
            double finalPrice = flight.getBasePrice() * (1 - discount);
            Ticket ticket = new Ticket(flight, passenger, finalPrice);
            bookings.add(ticket);
            System.out.println("Booking successful for passenger: " + passenger.getName());
            return ticket;
        } else {
            System.out.println("No seats available on flight " + flight.getFlightNumber());
            return null;
        }
    }

    public void listBookings() {
        if (bookings.isEmpty()) {
            System.out.println("No bookings available.");
        } else {
            System.out.println("Total Bookings: " + bookings.size());
            for (Ticket ticket : bookings) {
                ticket.displayTicket();
            }
        }
    }

    public Ticket findBookingByPassenger(Passenger passenger) {
        for (Ticket ticket : bookings) {
            if (ticket.getPassenger().equals(passenger)) {
                return ticket;
            }
        }
        System.out.println("No booking found for passenger: " + passenger.getName());
        return null;
    }

    public ArrayList<Ticket> findBookingsByFlight(Flight flight) {
        ArrayList<Ticket> flightBookings = new ArrayList<>();
        for (Ticket ticket : bookings) {
            if (ticket.getFlight().equals(flight)) {
                flightBookings.add(ticket);
            }
        }
        return flightBookings;
    }

    public boolean cancelBooking(Ticket ticket) {
        if (bookings.remove(ticket)) {
            ticket.getFlight().releaseSeat();
            System.out.println("Booking canceled for passenger: " + ticket.getPassenger().getName());
            return true;
        } else {
            System.out.println("Failed to cancel booking.");
            return false;
        }
    }
}